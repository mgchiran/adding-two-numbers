# include <iostream>
using namespace std;
int main()
{
  int x,y,z;
  cout << "enter 2 numbers:";
  cin >> x>>y;
  z=x+y;
  cout << "addition is "<<z;
  return 0;
}
